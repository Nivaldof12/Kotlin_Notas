package com.notas.ui

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.notas.R
import com.notas.models.Note
import com.notas.ui.NoteListItemAdapter.NoteListItemVH

class NoteListItemAdapter(private val noteList: MutableList<Note>) :
    RecyclerView.Adapter<NoteListItemVH>() {

    class NoteListItemVH(view: View) : RecyclerView.ViewHolder(view) {
        val tvNotePreview: TextView = view.findViewById(R.id.tv_note_preview)
        val tvNoteId: TextView = view.findViewById(R.id.tv_note_id)
        val tvNoteDate: TextView = view.findViewById(R.id.tv_note_date)
        val cardRoot: CardView = view.findViewById(R.id.card_root)

        init {
            cardRoot.visibility = View.INVISIBLE
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NoteListItemVH {
        return NoteListItemVH(
            LayoutInflater.from(parent.context).inflate(
                R.layout.view_note_list,
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: NoteListItemVH, position: Int) {
        val note = noteList[position]

        holder.tvNoteId.text = note.id
        holder.tvNoteDate.text = note.date
        holder.tvNotePreview.text = note.text
        holder.cardRoot.visibility = View.VISIBLE

        holder.cardRoot.setOnClickListener {
            val intent = Intent(holder.cardRoot.context, AddActivity::class.java)
            intent.putExtra(AddActivity.NOTE_KEY, note)
            holder.cardRoot.context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int {
        return noteList.size
    }
}