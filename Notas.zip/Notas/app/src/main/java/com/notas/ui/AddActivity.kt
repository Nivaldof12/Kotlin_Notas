package com.notas.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.location.Geocoder
import android.location.LocationManager
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.view.children
import androidx.core.widget.addTextChangedListener
import androidx.security.crypto.EncryptedFile
import androidx.security.crypto.MasterKeys
import com.google.gson.Gson
import com.notas.R
import com.notas.databinding.ActivityAddBinding
import com.notas.models.Note
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.charset.StandardCharsets
import java.text.SimpleDateFormat
import java.util.*

class AddActivity : AppCompatActivity() {
    private var pic: Bitmap? = null
    private var isViewing = false
    private lateinit var binding: ActivityAddBinding
    private val picIntentLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) {
                try {
                    pic = it.data?.extras?.get("data") as Bitmap
                    binding.imgNote.setImageBitmap(pic)
                    binding.imgNote.scaleType = ImageView.ScaleType.FIT_XY
                    binding.tvAddImgHint.visibility = View.GONE
                } catch (e: Exception) {
                    Log.e("ERROR/com.notas", "ERROR:AddActivity.kt", e)
                    Toast.makeText(this, "Ops! Ocorreu um erro.", Toast.LENGTH_SHORT).show()
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityAddBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        binding.imgNote.setOnClickListener {
            takePic()
        }

        with(intent.extras.takeIf { it != null && !it.isEmpty }) {
            val note = this?.getParcelable<Note>(NOTE_KEY)
            isViewing = true
            val locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager

            setTvLocation(binding.tvNoteLocation, locationManager)

            if (note != null) {
                binding.edTitle.setText(note.id)
                binding.edNote.setText(note.text)
                binding.tvNoteLocation.text = note.location

                binding.root.children.forEach { view ->
                    view.isClickable = false
                }

                if (note.imgPath != null) {
                    val keyGenParameterSpec = MasterKeys.AES256_GCM_SPEC
                    val mainKeyAlias = MasterKeys.getOrCreate(keyGenParameterSpec)
                    val file = File(
                        getExternalFilesDir(Environment.DIRECTORY_PICTURES)!!.path,
                        "${note.imgPath}"
                    )
                    val encryptedFile = EncryptedFile.Builder(
                        file,
                        applicationContext,
                        mainKeyAlias,
                        EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
                    ).build()

                    val inputStream = encryptedFile.openFileInput()

                    val bitmap =
                        BitmapFactory.decodeStream(inputStream)
                    binding.edNote.isEnabled = false
                    binding.edTitle.isEnabled = false
                    binding.imgNote.setImageBitmap(bitmap)
                    binding.imgNote.scaleType = ImageView.ScaleType.FIT_XY
                    binding.tvAddImgHint.visibility = View.GONE
                } else {
                    binding.cardNotePic.visibility = View.GONE
                }
            }
        }

        binding.edTitle.addTextChangedListener { text ->
            supportActionBar?.title =
                text.toString().ifEmpty { getString(R.string.new_note) }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1 && grantResults.isNotEmpty()) {
            setTvLocation(
                binding.tvNoteLocation,
                getSystemService(Context.LOCATION_SERVICE) as LocationManager
            )
        }

        if (requestCode == 2 && grantResults.isNotEmpty()) {
            takePic()
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        if (!isViewing) {
            try {
                val date = SimpleDateFormat.getDateInstance().format(Date())
                val fileName =
                    binding.edTitle.text.toString() + "(" + date.replace(" ", "-")
                        .replace(",", "") + ").fig"
                if (!binding.edTitle.text.isNullOrBlank() && !binding.edNote.text.isNullOrBlank()) {
                    saveNote(
                        Note(
                            binding.edTitle.text.toString(),
                            binding.edNote.text.toString(),
                            if (this.pic == null) null else fileName,
                            binding.tvNoteLocation.text.toString(),
                            date.toString()
                        )
                    )

                    if (this.pic != null) {
                        saveImageFile(fileName, this.pic!!)
                    }

                    finish()
                } else {
                    Toast.makeText(this, getString(R.string.fill_fields_alert), Toast.LENGTH_SHORT)
                        .show()
                    finish()
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Ocorreu um erro ao salvar sua nota!", Toast.LENGTH_SHORT)
                    .show()
                Log.e("ERROR/com.notes", "ERROR/AddActivity/SaveNote", e)
            }
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            if (!isViewing) {
                try {
                    val date = SimpleDateFormat.getDateInstance().format(Date())
                    val imageFileName = "${binding.edTitle.text}(${date})"
                    if (!binding.edTitle.text.isNullOrBlank() && !binding.edNote.text.isNullOrBlank()) {
                        saveNote(
                            Note(
                                binding.edTitle.text.toString(),
                                binding.edNote.text.toString(),
                                if (this.pic == null) null else imageFileName,
                                binding.tvNoteLocation.text.toString(),
                                date.toString()
                            )
                        )

                        if (this.pic != null) {
                            saveImageFile(imageFileName, this.pic!!)
                        }

                        finish()
                    } else {
                        Toast.makeText(
                            this,
                            getString(R.string.fill_fields_alert),
                            Toast.LENGTH_SHORT
                        )
                            .show()
                        finish()
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "Ocorreu um erro ao salvar sua nota!", Toast.LENGTH_SHORT)
                        .show()
                    Log.e("ERROR/com.notes", "ERROR/AddActivity/SaveNote", e)
                }
            } else {
                finish()
            }
        }

        return true
    }

    private fun setTvLocation(textView: TextView, locationManager: LocationManager) {
        if (ActivityCompat.checkSelfPermission(
                this@AddActivity,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this@AddActivity,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), 1)
            textView.text = getString(R.string.location_loading)
        } else {
            locationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER, 0, 0f
            ) { loc ->
                val geocoder = Geocoder(this@AddActivity, Locale.getDefault())
                val addresses = geocoder.getFromLocation(loc.latitude, loc.longitude, 1)

                binding.tvNoteLocation.text =
                    getString(R.string.location_template, addresses[0].getAddressLine(0))
            }
        }
    }

    private fun saveImageFile(fileName: String, bitmap: Bitmap) {
        try {
            val storageDir: File = getExternalFilesDir(Environment.DIRECTORY_PICTURES)!!
            val file = File(storageDir.path, fileName)

            val bmpBytes = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bmpBytes)

            val keyGenParameterSpec = MasterKeys.AES256_GCM_SPEC
            val mainKeyAlias = MasterKeys.getOrCreate(keyGenParameterSpec)

            val encryptedFile = EncryptedFile.Builder(
                file,
                applicationContext,
                mainKeyAlias,
                EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
            ).build()

            encryptedFile.openFileOutput().apply {
                write(bmpBytes.toByteArray())
                flush()
                close()
            }
        } catch (e: Exception) {
            Log.e("ERROR/com.notas", "ERROR:AddActivity.kt", e)
            Toast.makeText(this, "Ops! Ocorreu um erro.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun takePic() {
        if (ActivityCompat.checkSelfPermission(
                this@AddActivity,
                Manifest.permission.CAMERA
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), 2)
        } else {
            val takePicIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            picIntentLauncher.launch(takePicIntent)
        }
    }

    private fun saveNote(note: Note) {
        try {
            val storageDir: File = filesDir
            val file = File(
                storageDir.path,
                "${note.id}(${
                    note.date?.replace(" ", "-")
                        ?.replace(",", "-")
                }).txt"
            )

            val gson = Gson()
            val json = gson.toJson(note)

            val keyGenParameterSpec = MasterKeys.AES256_GCM_SPEC
            val mainKeyAlias = MasterKeys.getOrCreate(keyGenParameterSpec)


            val encryptedFile = EncryptedFile.Builder(
                file,
                applicationContext,
                mainKeyAlias,
                EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
            ).build()

            encryptedFile.openFileOutput().apply {
                write(json.toByteArray(StandardCharsets.UTF_8))
                flush()
                close()
            }

        } catch (e: Exception) {
            Log.e("ERROR/com.notas", "ERROR:AddActivity.kt", e)
            Toast.makeText(this, "Ops! Ocorreu um erro.", Toast.LENGTH_SHORT).show()
        }
    }

    companion object {
        const val NOTE_KEY = "note"
    }
}