package com.notas.ui.main_activity

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.edit
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.billingclient.api.*
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.MobileAds
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.notas.R
import com.notas.databinding.ActivityMainBinding
import com.notas.models.Note
import com.notas.ui.AddActivity
import com.notas.ui.NoteListItemAdapter
import com.notas.ui.login_activity.LoginActivity
import com.notas.ui.login_activity.LoginActivity.Companion.PREMIUM
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: MainViewModel
    private var isPremium = false
    private val firebaseAuth = FirebaseAuth.getInstance()
    private val firestore = FirebaseFirestore.getInstance()
    private val noteList: MutableList<Note> = mutableListOf()
    private val noteTitleList: MutableList<String> = mutableListOf()
    private val purchasesUpdatedListener =
        PurchasesUpdatedListener { billingResult, purchases ->
            if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                if (purchases?.isNotEmpty() == true) {
                    firestore.collection("premium").document(firebaseAuth.currentUser!!.uid)
                        .set(Pair("isPremium", true)).addOnSuccessListener {
                            Toast.makeText(
                                this,
                                "Sua compra foi realizada com sucesso",
                                Toast.LENGTH_SHORT
                            ).show()
                            binding.btnPremium.visibility = View.GONE
                            binding.adView.visibility = View.GONE
                            getSharedPreferences(
                                getString(R.string.PREFS),
                                Context.MODE_PRIVATE
                            ).edit {
                                putBoolean(PREMIUM, true)
                                commit()
                            }
                        }
                }
            } else {
                Toast.makeText(
                    this@MainActivity,
                    getString(R.string.billing_error),
                    Toast.LENGTH_LONG
                ).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        viewModel = MainViewModel(application)

        installSplashScreen().setKeepOnScreenCondition {
            if (viewModel.isLoading.value) {
                true
            } else {
                if (!viewModel.isLoggedIn.value) {
                    startActivity(Intent(this@MainActivity, LoginActivity::class.java))
                    finish()
                } else {
                    binding.btnLogout.setOnClickListener {
                        firebaseAuth.signOut()
                        finish()
                    }
                    binding.root.visibility = View.VISIBLE
                    isPremium = getSharedPreferences(
                        getString(R.string.PREFS),
                        Context.MODE_PRIVATE
                    ).getBoolean(PREMIUM, false)

                    if (isPremium) {
                        binding.btnPremium.visibility = View.GONE
                        binding.adView.visibility = View.GONE
                    } else {
                        MobileAds.initialize(this)
                        binding.adView.loadAd(AdRequest.Builder().build())

                        val billingClient = BillingClient.newBuilder(this)
                            .setListener(purchasesUpdatedListener)
                            .enablePendingPurchases()
                            .build()

                        billingClient.startConnection(object : BillingClientStateListener {
                            override fun onBillingServiceDisconnected() {
                                Toast.makeText(
                                    this@MainActivity,
                                    getString(R.string.billing_error),
                                    Toast.LENGTH_LONG
                                ).show()
                            }

                            override fun onBillingSetupFinished(billingResult: BillingResult) {
                                if (billingResult.responseCode != BillingClient.BillingResponseCode.OK) {
                                    Log.e(
                                        "TAG",
                                        "onBillingSetupFinished: 1 ${billingResult.debugMessage}",
                                    )
                                    Toast.makeText(
                                        this@MainActivity,
                                        getString(R.string.billing_error),
                                        Toast.LENGTH_LONG
                                    ).show()

                                    binding.btnPremium.setOnClickListener {
                                        Toast.makeText(
                                            this@MainActivity,
                                            getString(R.string.billing_error),
                                            Toast.LENGTH_LONG
                                        ).show()
                                    }
                                } else {
                                    val skuList = ArrayList<String>()
                                    skuList.add("android.test.purchased")
                                    val params = SkuDetailsParams.newBuilder()
                                    params.setSkusList(skuList).setType(BillingClient.SkuType.INAPP)

                                    MainScope().launch {
                                        withContext(Dispatchers.IO) {
                                            billingClient.querySkuDetailsAsync(
                                                params.build()
                                            ) { bResult, skuDetailList ->
                                                if (bResult.responseCode != BillingClient.BillingResponseCode.OK) {
                                                    Log.e(
                                                        "TAG",
                                                        "onBillingSetupFinished: 1 ${billingResult.debugMessage}",
                                                    )
                                                    Toast.makeText(
                                                        this@MainActivity,
                                                        getString(R.string.billing_error),
                                                        Toast.LENGTH_LONG
                                                    ).show()

                                                    binding.btnPremium.setOnClickListener {
                                                        Toast.makeText(
                                                            this@MainActivity,
                                                            getString(R.string.billing_error),
                                                            Toast.LENGTH_LONG
                                                        ).show()
                                                    }
                                                } else {
                                                    Log.e(
                                                        "TAG",
                                                        "onBillingSetupFinished: Google Play Billing API successfully started."
                                                    )
                                                    binding.btnPremium.setOnClickListener {
                                                        val flowParams =
                                                            BillingFlowParams.newBuilder()
                                                                .setSkuDetails(skuDetailList!![0]!!)
                                                                .build()
                                                        val responseCode =
                                                            billingClient.launchBillingFlow(
                                                                this@MainActivity,
                                                                flowParams
                                                            ).responseCode
                                                    }
                                                }
                                            }
                                        }


                                    }
                                }
                            }
                        })
                    }


                }
                false
            }
        }

        binding.fabMain.setOnClickListener {
            val intent = Intent(this, AddActivity::class.java)
            startActivity(intent)
        }

        binding.rvNotes.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)

            setHasFixedSize(false)

            adapter = NoteListItemAdapter(noteList)

            addOnScrollListener(object : RecyclerView.OnScrollListener() {
                override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                    super.onScrolled(recyclerView, dx, dy)
                    if (dy > 10) {
                        toggleFAB(binding.fabMain)
                    }
                }
            })
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.getNotes(noteList, noteTitleList)

        if (noteList.size > 0) {
            binding.rvNotes.visibility = View.VISIBLE
            binding.tvNoNotes.visibility = View.GONE
        }

        binding.rvNotes.adapter?.notifyDataSetChanged()
    }

    private fun toggleFAB(view: FloatingActionButton) {
        if (view.isShown) {
            view.hide()
        } else {
            view.show()
        }
    }
}