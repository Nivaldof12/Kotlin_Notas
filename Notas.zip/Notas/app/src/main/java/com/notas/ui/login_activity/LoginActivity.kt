package com.notas.ui.login_activity

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.edit
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.notas.R
import com.notas.databinding.ActivityLoginBinding
import com.notas.ui.main_activity.MainActivity

class LoginActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore

    private lateinit var binding: ActivityLoginBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        db = FirebaseFirestore.getInstance()

        auth = FirebaseAuth.getInstance()

        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (auth.currentUser != null) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        } else {
            binding.btnLogin.setOnClickListener {
                signIn(binding.edEmail, binding.edPasswd)
            }

            binding.btnRegister.setOnClickListener {
                register(binding.edEmail, binding.edPasswd)
            }
        }
    }

    private fun register(email: EditText, passwd: EditText) {
        if (email.text.toString().isEmpty()) {
            email.error = "Informe um endereço de e-mail"
            return
        }

        if (passwd.text.toString().isEmpty() || passwd.text.toString().length < 6) {
            passwd.error = "Informe uma senha com no mínimo 6 digitos"
            return
        }

        auth.createUserWithEmailAndPassword(email.text.toString(), passwd.text.toString())
            .addOnCompleteListener {
                if (!it.isSuccessful) {
                    Log.e("TAG", "register: ${it.exception}", it.exception)
                    Toast.makeText(
                        this,
                        "Ops! Ocorreu um erro! Verifique seu e-mail e senha.",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    val intent = Intent(this, MainActivity::class.java)
                    getSharedPreferences(getString(R.string.PREFS), Context.MODE_PRIVATE).edit {
                        putBoolean(PREMIUM, false)
                        commit()
                    }
                    startActivity(intent)
                }
            }
    }

    private fun signIn(email: EditText, passwd: EditText) {
        if (email.text.toString().isEmpty()) {
            email.error = "Informe um endereço de e-mail"
            return
        }

        if (passwd.text.toString().isEmpty() || passwd.text.toString().length < 6) {
            passwd.error = "Informe uma senha com no mínimo 6 digitos"
            return
        }

        auth.signInWithEmailAndPassword(email.text.toString(), passwd.text.toString())
            .addOnCompleteListener { result ->
                if (!result.isSuccessful) {
                    Toast.makeText(
                        this,
                        "Ops! Ocorreu um erro! Verifique seu e-mail e senha.",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    db.collection("premium").document(result.result.user!!.uid).get()
                        .addOnCompleteListener {
                            if (it.isSuccessful) {
                                if (it.result.exists()) {
                                    val intent = Intent(this, MainActivity::class.java)
                                    getSharedPreferences(getString(R.string.PREFS), Context.MODE_PRIVATE).edit {
                                        putBoolean(PREMIUM, true)
                                        commit()
                                    }
                                    startActivity(intent)
                                } else {
                                    getSharedPreferences(getString(R.string.PREFS), Context.MODE_PRIVATE).edit {
                                        putBoolean(PREMIUM, false)
                                        commit()
                                    }
                                    val intent = Intent(this, MainActivity::class.java)
                                    startActivity(intent)
                                }
                            } else {
                                Toast.makeText(
                                    this,
                                    "Ops! Ocorreu um erro! Verifique seu e-mail e senha.",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                }
            }
    }

    companion object {
        const val PREMIUM = "premium"
    }
}
