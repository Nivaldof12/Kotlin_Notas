package com.notas.ui.main_activity

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.security.crypto.EncryptedFile
import androidx.security.crypto.MasterKeys
import com.google.firebase.auth.FirebaseAuth
import com.google.gson.Gson
import com.notas.models.Note
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.nio.charset.StandardCharsets

class MainViewModel(private val app: Application) : AndroidViewModel(app) {
    private val _isLoading = MutableStateFlow(true)
    private val _isLoggedIn = MutableStateFlow(false)
    val isLoggedIn = _isLoggedIn.asStateFlow()
    val isLoading = _isLoading.asStateFlow()

    init {
        viewModelScope.launch {
            if (FirebaseAuth.getInstance().currentUser != null) {
                _isLoading.value = false
                _isLoggedIn.value = true
            } else {
                _isLoggedIn.value = false
                _isLoading.value = false
            }
        }
    }

    fun getNotes(noteList: MutableList<Note>, titleList: MutableList<String>) {
        val filesDir = app.filesDir
        filesDir.listFiles { noteFile ->
            if (noteFile.name.endsWith(".txt")) {
                val gson = Gson()
                val keyGenParameterSpec = MasterKeys.AES256_GCM_SPEC
                val mainKeyAlias = MasterKeys.getOrCreate(keyGenParameterSpec)

                val encryptedFile = EncryptedFile.Builder(
                    noteFile,
                    app.applicationContext,
                    mainKeyAlias,
                    EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
                ).build()

                val inputStream = encryptedFile.openFileInput()
                val byteArrayOutputStream = ByteArrayOutputStream()
                var nextByte: Int = inputStream.read()
                while (nextByte != -1) {
                    byteArrayOutputStream.write(nextByte)
                    nextByte = inputStream.read()
                }

                val plaintext: ByteArray = byteArrayOutputStream.toByteArray()
                val note =
                    gson.fromJson(String(plaintext, StandardCharsets.UTF_8), Note::class.java)
                if (!titleList.contains(note.id)) {
                    noteList.add(note)
                    titleList.add(note.id!!)
                }
            }

            return@listFiles true
        }
    }
}